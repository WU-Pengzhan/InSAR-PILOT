# Web 外壳与逐页交互原则

Web 是唯一继续开发的产品端。Vue 3/TypeScript/Quasar、Leaflet 检索地图、
OpenLayers/Proj4js 成果地图和 ECharts 图表保持。PySide6/Qt 不再接受界面开发任务。

## 工程与导航

Home 提供最近工程、新建、打开、全局 Explore。工程 Profile 决定专业页面；
Sentinel 页面提案见 [sentinel-workbench](sentinel-workbench.md)，NISAR 后续单独设计。
公共外壳提供左侧导航、中央页面/对象子视图、可收起 Inspector、任务/状态栏和 Compute。

五个 Sentinel 主页面是当前提案，不直接代表现有 App.vue 已按此重构。
导航表达工作顺序但允许返回；修改输入须反馈计划/成果过期原因。
Recipe 与页面分离，正式阶段和 run-file 不作为全局导航菜单身份。

## 平台和持久性

Ubuntu 浏览器与 Windows 浏览器访问 WSL 使用同一 HTTP/Vue 界面。
服务仅 loopback，受本机会话与 Origin 保护；文件按注册资源 ID 访问。
浏览器刷新/关闭不取消任务；慢客户端不阻塞执行。后端状态决定成败，未知进度不猜百分比。
构建后前端随包分发，用户不需要 Node、Electron 或 WSLg。

共享状态跨页一致；运行不抢焦点。保留原 Logo、中英文、明暗主题和可恢复的属性栏尺寸。

## 文件选择与地图

文件选择浏览的是服务主机目录，不上传巨大 SAR 数据、不调用 Qt 或浏览器专有文件 API。
Linux 使用本机路径；WSL 可浏览已挂载 Windows 盘，Windows/当前 WSL UNC 路径按可核验规则转换。
位置侧栏、地址栏、面包屑、过滤和操作区固定；内部列表滚动，切换目录不改变浮层尺寸。

检索底图使用纯影像，保留必要署名，不增加地名/行政边界或街道 fallback。
AOI/BBOX/WKT/KML/Shapefile、footprint 与任务专属筛选保留。Sentinel/NISAR 的过滤和获取策略独立。

成果地图只使用真实 CRS/坐标轴或验证过的 geolocation；雷达图像可在影像视图查看。
大数据按需窗口/采样展示，重投影/瓦片是显示派生。暂缓昂贵相位统计不影响基础可读性检查。

## 任务与退出

下载清单在传输前可见，显示场景和文件、路径、进度及诊断，提供暂停/继续/取消/重试。
运行页可看科学步骤、批次、逐步基础检查和日志；下载暂停不意味着科学任务支持任意断点恢复。

顶部连接状态和“退出应用”明确区分后台运行、正在退出、退出完成、意外断线。
活动任务/worker 阻止退出，入口引导至任务控制；空闲关闭保留所有项目与历史。
CLI --status / --stop 不启动缺失的服务。用户关闭标签页不能被当成退出软件。

## API 与单页验收

沿用 /api/v1 的 Projects、Data、Pipeline/Plans、Runs、Jobs、Artifacts/QC/Layers、
Events/Logs、Compute 和 Application 生命周期接口。响应合同按页补齐类型，不从文件名推断状态。

每页先定义输入输出/正常异常/返回修改，再完成所需 backend/API 与前端。
检查相关 Linux Firefox/Chromium、Windows 浏览器到 WSL、1440×900/1366×768、
中英/主题、空/加载/错误/长路径与大列表；原生缩放需实际检查，不用小视口冒充通过。
一次只实现和验收一个约定页面，未完成矩阵如实标注。
